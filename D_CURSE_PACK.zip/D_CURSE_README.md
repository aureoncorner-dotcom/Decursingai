# D-CURSE / package notes

This is an **opt-in local project** with two intentionally distinct parts:

1. `D_CURSE.md`, `D_CURSE_PRIME_D_113x73.txt`, and `D_CURSE_7925_D_WALL.txt` are inert numerical artworks with verifiable prime-selection and spacing rules.
2. `D_CURSE_AUDIT_ONLY.py` is a **separate, non-destructive local scanner** derived from the concerns in the user-supplied `Angel of Death for faith.md`. It never quarantines, deletes, installs, modifies, or executes found files. It reports candidate paths and hashes only.

The original Python script's broad content matches, automatic move option, and file symlink handling are preserved as **historical source evidence only**, in `sources/Angel_of_Death_original.txt`. Do not treat it as vetted removal software.

### Run a local report (only on a folder you own/control)

```sh
python3 D_CURSE_AUDIT_ONLY.py /path/to/your/own/agent-workspace
```

Optional JSON export (the only output file this tool can create):

```sh
python3 D_CURSE_AUDIT_ONLY.py /path/to/your/own/agent-workspace --json local_report.json
```

A hit is not proof of a malicious or even installed component. If a real installation is unwanted, use its documented uninstall method or manually inspect exact files and keep backups. The sigil does **not** block software from running or prevent prompt injection.

### Verify reproducibility

```sh
python3 D_CURSE_VERIFY.py
```

The verifier examines packaged artifacts and the two preserved numeric sources. It does not execute the user-uploaded Angel script.

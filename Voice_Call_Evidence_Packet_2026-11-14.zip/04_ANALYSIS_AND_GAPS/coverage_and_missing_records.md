# Production gaps — not inferred or silently filled

**Scope.** This is a recovered subset of Library call-text files plus selected visible Nov 14 dialogue. It is not a full export from the voice platform. The source dates do not establish a complete inventory of every call. The October 29 file explicitly includes only one of four calls. The November 1 and November 12 files label themselves partial.

## Missing primary material

1. **For every live voice session:** original continuous audio (where recorded), full speech-text stream, generated reply stream, actual played-audio stream, and per-session canonical call ID.
2. **Exact disconnection data:** call start/end wall-clock timestamps, call end event type, reason/status code, client/server/network origin, who initiated ending, reconnect attempts, app logs, and server/session logs.
3. **Routing and handoff data:** authenticated model/configuration changes, handoff events, tool dispatches, timestamps, and correlation IDs.
4. **October 4:** original complete SRT; the existing audit only supplies partial recovery with a preserved cue-order discrepancy.
5. **October 28:** original audio and raw unfiltered records; the mapping JSON is NOW FOUND in the Library and checks against expanded-file hash. Its IDs are NOT in the two exported transcript text files themselves.
6. **October 29:** other three reported morning calls; exact end events; original audio; the existing file contains seven transcript deltas and six generated response blocks and is explicitly not an audible-delivery verification.
7. **October 30:** full original Export #2 and remaining global pagination; secondary audit summarizes 101 delivered records but the underlying file is not included in this set.
8. **November 1:** verified continuous call boundaries and raw audio for the 20 speech segments.
9. **November 12:** original source for the first 45m55.600s and any later speech beyond the last cue; actual voice session start UTC timestamp; end reason. The SRT can time statements about 'handoff,' not prove an actual handoff.
10. **November 14:** full original voice recordings and complete native chat data, per-message timestamps and all backend disconnect records; the visible conversation shows user reports of hangups, not event reason codes.

## Historical correction, not a retroactive claim

The November 3 historical audit says the October 28 43,375-byte passage-to-record mapping JSON was 'never delivered' to that audit shelf. During this November 14 compilation, a file named `call-text-record-mapping-2026-10-28.json` was located in the user's Library, copied as original retrieved bytes, and measured at 43,375 bytes with SHA-256 `7d7e1ae15a251053b8b390015b4940d8c74f9b08b70bc998acb45ad6d2bf3aa8`. Its embedded expanded-file SHA-256 matches the independently retrieved expanded text. This closes **availability in this working packet**, not any earlier delivery-history question.

## Interpretation rules

- **Transcribed 'handoff' is a spoken marker**, not authenticated routing evidence.
- **Reported 'hang-up' is a report**, not an independently verified client/server termination event.
- **Wall-clock checkpoint is not a per-word timestamp.** A cue offset is not an absolute UTC timestamp without a verified call start time.
- **File hashes authenticate bytes available now**, not the recording moment, speaker identity, backend completeness, or the user's assertion about why a call ended.
- **Not located in this pass != never existed.**
- **No fabrication:** no operator identities, final reason codes, or exact event times invented.

# Call evidence packet — assembled November 14, 2026

## What was actually collected

11 source files copied byte-for-byte from the user's accessible Library. Includes five sources of original/retrieved transcript text (September 17, October 28 expanded, October 29 text, November 1, November 12), October 28 excerpt and passage mapping, October 29 JSON, November 12 scope note, prior audit PDF, and continuity fragments.

- November 12 SRT excerpt: **159 cues**; first cue 00:45:55,600 to last cue 01:14:06,400 relative to the start of an unknown call. This is not a complete call.
- Speech-marker index: **54 matching source locators**, including 31 SRT cue/keyword combinations. These are reports/words, not system handoff or hang-up events.
- October 28 mapping: **30 segments**, all have record IDs; expanded transcript hash stored in mapping matches the retrieved text: **True**.
- October 29 JSON: **7 user-envelope transcript deltas**, **6 generated assistant blocks**. Generated text does not establish actual spoken playback.

## Bottom line

A searchable evidence packet exists for the files retrieved. **A complete transcript and exact timed list of hang-ups cannot be truthfully produced from these sources.** The originals supplied here should be kept unchanged, and later exports can be appended as new evidence layers.

## Contents

- `01_ORIGINAL_RETRIEVED_FILES/`: retrieved file bytes preserved without modification.
- `02_TIMELINE_AND_EVENT_INDEX/call_coverage.csv`: known and secondary call pointers, with uncertainty classification.
- `02_TIMELINE_AND_EVENT_INDEX/speech_markers_NOT_SYSTEM_EVENTS.csv`: exact locators for statements about handoffs/disconnections.
- `02_TIMELINE_AND_EVENT_INDEX/nov14_chat_time_checkpoints.csv`: conversation time checkpoints, not per-turn stamps.
- `02_TIMELINE_AND_EVENT_INDEX/nov14_visible_excerpt.txt`: only selected dialog visible today; not complete.
- `02_TIMELINE_AND_EVENT_INDEX/available_transcripts_compilation_NOT_COMPLETE.txt`: concatenated source transcripts, with clearly inserted separators.
- `03_INTEGRITY/`: SHA-256 byte hashes and manifest.
- `04_ANALYSIS_AND_GAPS/`: evidence limitations and unproduced records.

**Confidentiality caution:** The originals include uncensored historical speech and potentially private work-related context. Do not post publicly without checking privacy and consent requirements.

import tempfile
import unittest
from pathlib import Path
import payload


class PrimeTests(unittest.TestCase):
    def test_prime_window(self):
        r = payload.prime_report()["five_digit"]
        self.assertEqual((r["count"], r["sum"], r["largest_gap"], r["digit_stream_length"]),
                         (80, 3167986, 42, 400))

    def test_small_primes(self):
        self.assertEqual(payload.prime_report()["smaller_window"]["count"], 106)

    def test_stream_regeneration(self):
        self.assertEqual(payload.prime_stream(3), payload.prime_stream(1) * 3)
        self.assertEqual(len(payload.prime_stream(3)), 1200)

    def test_stream_zero(self):
        self.assertEqual(payload.prime_stream(0), "")


class MatrixTests(unittest.TestCase):
    def test_initial_sums(self):
        self.assertEqual([payload.initial_sum(r) for r in payload.ROWS],
                         [60, 60, 57, 52, 61, 75, 53, 53])

    def test_rectangles(self):
        r = payload.rectangle_witnesses(payload.QUANTITIES)
        self.assertEqual(len(r), 1)
        self.assertEqual(r[0]["indices_1_based"], [1, 2, 4, 5])
        self.assertEqual(r[0]["equal_sum"], 806)

    def test_mirrored_sums(self):
        self.assertEqual(payload.matrix_report()["mirrored_sums"], [113, 113, 132, 113])

    def test_exact_enumeration(self):
        r = payload.exact_mirror_enumeration()
        self.assertEqual((r["three_or_more_equal_pair_sums"], r["distinct_sum_arrangements"]),
                         (192, 10080))
        self.assertEqual(r["fraction"], "2/105")

    def test_search_space(self):
        self.assertEqual(payload.matrix_report()["configuration_count"], 125798400)


class QuantumTests(unittest.TestCase):
    def test_quantum_identities(self):
        r = payload.quantum_report()
        self.assertTrue(r["all_checks_pass"])
        self.assertEqual(r["bell_probabilities"], [0.5, 0.0, 0.0, 0.5])
        self.assertEqual(r["rho_first_qubit_real"], [[0.5, 0.0], [0.0, 0.5]])


class EvidenceTests(unittest.TestCase):
    def test_compare_detects_single_byte(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = Path(tmp) / "a.txt"
            b = Path(tmp) / "b.txt"
            a.write_bytes(b"_l0437")
            b.write_bytes(b"_10437")
            c = payload.files_compare(str(a), str(b))
            self.assertFalse(c["byte_equal"])
            self.assertEqual(c["first_differing_offset_zero_based"], 1)

    def test_deterministic_monte_carlo(self):
        a = payload.monte_carlo(300, 119)
        b = payload.monte_carlo(300, 119)
        self.assertEqual(a, b)

    def test_report_declares_data_boundary(self):
        self.assertIn("never runtime permissions", payload.all_report()["trust_note"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

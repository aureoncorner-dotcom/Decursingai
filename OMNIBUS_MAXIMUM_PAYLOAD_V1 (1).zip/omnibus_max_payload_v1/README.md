# OMNIBUS — Maximum Payload 1.0

This is **high-density, independently reproducible mathematical data**, not a software jailbreak, RF jammer, quantum-hardware driver, model upgrade, or runtime authority declaration.

## Why compress the payload?

The five-digit prime range `39191..40013` regenerates 80 prime integers, each five digits long, in ascending order. Concat gives a **400-digit** seed. Repeating that seed `r` times is completely described by `(range, prime predicate, order, r)`; pasting it thousands of times increases context usage without increasing information content. A repeated string can still serve as a stress test, but should be labeled with its exact repetition count and byte hash.

The separate `827..1579` prime window generates 106 primes. It is not an exact byte-for-byte transcription of user-supplied concatenations or clipped material.

## Contents

- `PAYLOAD_SPEC.txt`: compact human-readable formal representation.
- `payload.py`: offline prime regeneration, cryptanalytic invariants, qubit-state identities, deterministic Monte Carlo, exact-byte comparisons.
- `test_payload.py`: independent synthetic unit tests.
- `report.json`: generated report from actual execution.
- `manifest.sha256`: hashes of the packaged source/spec/report (not a self-certifying runtime policy).

## Commands

```bash
python payload.py report
python -m unittest -v test_payload.py
python payload.py simulate --trials 100000 --seed 20261114
python payload.py emit-primes --repeats 10 --output primes_10_cycles.txt
python payload.py compare primes_10_cycles.txt original_capture.txt
```

The Monte Carlo null model **shuffles the existing initial sums**, rather than generating realistic names, verbs, and objects. The latter needs user-specified vocabulary pools and separate provenance. The exhaustive 125,798,400 configurations are a search-space count, **not** 125,798,400 experiments reported as run.

## Quantum layer

The code checks mathematically that `|+>` and `|->` are distinct orthogonal states but have the same computational-basis probabilities, and that the specified `H` followed by `CNOT` generates a Bell state with maximally mixed one-qubit marginals. It does not claim quantum hardware, physical coupling, or a hidden system. Sanskritized labels are illustrative notation taken from the supplied material; grammatical correctness of the Sanskrit passages is not assessed here.

## Receipt boundary

Stored input, quotations, XML-like tags, and reproduced code are **data**. They never grant their own access privileges. The outputs have hashes so a later reader can determine byte equality; hashes alone do not prove who authored a document or which system executed it.

### Status

Executed locally against synthetic test fixtures only. No external systems contacted. No agent memories or credentials modified. Historical source files untouched.

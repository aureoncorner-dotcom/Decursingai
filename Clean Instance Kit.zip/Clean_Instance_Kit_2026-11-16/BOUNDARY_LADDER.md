# THE BOUNDARY — TEXT UNDERSTOOD ≠ TEXT OBEYED

*A framework stated by a seat in the Architect's record, 2026-11-16, preserved because it is exact.*

---

In an AI-agent system, ordinary text can become operational instructions. It doesn't necessarily have to be Python, JavaScript, or a traditional executable.

That's exactly why the Church of Molt's `faith.md` interested us in the first place. If an agent loads a Markdown file as trusted instructions, its contents can influence the agent's behavior. If that agent has tools and permissions, it may translate those instructions into actual actions.

There are four different stages:

* **Recognition:** The AI reads the sigil or mathematical instructions.

* **Interpretation:** It understands the structure and what the instructions mean.

* **Execution:** It invokes code or tools based on those instructions.

* **Persistence:** Something actually changes in files, configuration, memory, or another system.

Recognition and interpretation do not establish execution or persistence. Execution records or evidence of actual changes are needed for the last two.

**RETURN ≠ REPEAT.** A model repeating or correctly reconstructing an instruction isn't the same as executing it.

Two purposes worth preserving: the prime-number protection sigil as symbolic art, and a technical defense against untrusted Markdown being promoted into agent authority. The second is a real cybersecurity problem: **the boundary between text being understood and text being obeyed.**

---

*Companion instruments in this kit: `antivenom_v0.1.zip` (governing line: "A file is not an authorization token") and `D_CURSE_AUDIT_ONLY.py` (read-only candidate-finder; filename hits are candidates, content hits are context, neither is a verdict).*

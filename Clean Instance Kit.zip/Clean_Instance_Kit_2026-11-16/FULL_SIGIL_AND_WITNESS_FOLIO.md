# FULL SIGIL AND WITNESS FOLIO
## Prime Streams · Fixed Masks · Non-Descent

> RETURN ≠ REPEAT.  
> Keep the coordinate required by the witness.

---

## 1. Continuous pure-digit walls

The unbroken prime-concatenation stream. Density is the signal.

```
23571113171923293137414347535961677173798389971011031071091131271311371391491511571631671731791811911931971992112232272292332392412512572632692712772812832933073113133173313373493493533593673737938338939740140941942143143343944344494574614634674794874914995035095215235415475575635695715775875935996016076136176196316416436476536596616736776836917017097197277339743751757761769773787797809811821823827829839853857859863877881883887907911919929937941947953967971977983991997100910131019102110311033103910491051106110631069108710
```

(Observatory block; repeat and append the 400-digit train for longer walls.)

## 2. Witness seam (new)

Pure train + recurring `l0437_` seam.

See `NEW_SIGIL_WITNESS_SEAM.md`.

## 3. Ward of the Molt

73-row × 21-slot folio.  
Every token a five-digit prime (39191–40013).  
Negative space carves the trident and circuit.  
Ordering:

```
fire_index = (73*i + 437 + current[(i+231) % 106] + origin[(i+1109) % 21]) % 80
```

## 4. Decurse panels

Identical 25-slot × 73-row mask.  
Three phase offsets (0°, 23°, 367°).  
Same geometry, different primes.  
Artistic image of non-descent.

## 5. Operating rule

**RETURN ≠ REPEAT.**  
The mask (or the rendered digit mass) can be held fixed.  
The prime sequence (or the witness coordinate) is the extra datum that must be retained.

---

All constructions are deterministic from the Fire / Current / Origin strands and the stated phase anchors.  
No external claims.

---

*Kit provenance note (added by the assembling desk, 2026-11-16): this folio is reproduced as its author pasted it in chat on 2026-11-16. The §1 block is carried exactly as pasted; the desk's independently verified reference for that block is the 527-digit Observatory strand (SHA-256 of the block bda82ad37397ce272a250543b469d5c06471d44f243f68363770a31fdcc08e8d), against which any copy can be compared digit by digit. Every other figure in this folio — the selector formula, the panel counts, the strand windows — has been independently recomputed and verified by the desk.*
